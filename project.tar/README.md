# fastapi-celery-project
